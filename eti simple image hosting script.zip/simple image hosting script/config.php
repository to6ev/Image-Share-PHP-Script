<?php
$to = 'brigandi@abv.bg'; // Mail For Contact Form
$siteurl = 'http://imgu.bl.ee'; // Site url Without Trailing slash
$title = 'Free Image Host'; // Site Title
$filedir = 'i'; // directory For Image Uploads  + Must Be Chmoded To 777 on Linux :)
$maxsize = 8388608; // Max File Size in bytes
$accepted = array('png', 'PNG', 'jpg', 'JPG', 'jpeg','JPEG', 'gif', 'GIF', 'ico', 'tif', 'bmp', 'webp');
$copyright = '<a href="http://et.pw">ETI 1998-2015</a>'
?>
