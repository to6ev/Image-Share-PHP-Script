﻿<?php
include('config.php');
?>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<LINK REL="SHORTCUT ICON" href="avatar brigante.jpg">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="Description" content="Free Image Host - Share Pictures">
<meta name="Keywords" content="free image hosting, image host, upload pictures, share pictures, pic share" />
<meta name="Distribution" content="Free Image Host" />
<meta name="Author" content="www.ETI.pw" />
<meta name="Robots" content="index,follow" />
<style type="text/css">
body {
  height: 100%;
  width: 100%;
  background: url(images/box.jpg) ; 
}
</style>
<title><?php print $title; ?></title>
</head>
<body>
		
<h1><a href="./"><?php print $title; ?></a>		
<script type="text/javascript">
    $(function() {
        $('#bookmarkme').click(function() {
            if (window.sidebar && window.sidebar.addPanel) { // Mozilla Firefox Bookmark
                window.sidebar.addPanel(document.title,window.location.href,'');
            } else if(window.external && ('AddFavorite' in window.external)) { // IE Favorite
                window.external.AddFavorite(location.href,document.title); 
            } else if(window.opera && window.print) { // Opera Hotlist
                this.title=document.title;
                return true;
            } else { // webkit - safari/chrome
                alert('Press ' + (navigator.userAgent.toLowerCase().indexOf('mac') != - 1 ? 'Command/Cmd' : 'CTRL') + ' + D to bookmark this page.');
            }
        });
    });
</script>
<a id="bookmarkme" href="#" rel="sidebar" title="Free Image Share"><img src="bookmark.png" border="0" alt="Bookmark this page! Add to favorites!" title="Bookmark this page! Add to favorites!" /></a></h1>

<p>Share Pictures with somebody:)</p>		
			
<center>
<?php
include('config.php');
if($_SERVER['REQUEST_METHOD'] == 'POST') {

    preg_match('/\.([a-zA-Z]+?)$/', $_FILES['file']['name'], $matches);

    if(in_array(strtolower($matches[1]), $accepted)) {

        if($_FILES['file']['size'] <= $maxsize) {

            $newname = md5_file($_FILES['file']['tmp_name']).'.'.$matches[1];

            move_uploaded_file($_FILES['file']['tmp_name'], $filedir.'/'.$newname);

            $linkurl = 'http://'.$_SERVER['HTTP_HOST'].preg_replace('/\/([^\/]+?)$/', '/', $_SERVER['PHP_SELF']).'#'.$newname;

            $imgurl = 'http://'.$_SERVER['HTTP_HOST'].preg_replace('/\/([^\/]+?)$/', '/', $_SERVER['PHP_SELF']).$filedir.'/'.$newname;
			$alt = $_POST["alt"];

            print '<h2>Picture Uploaded Successfuly!</h2> <p id="codes">
         
          <img src="'.$imgurl.'" height="300" alt="Uploaded Picture" >
<br />
<br />
Direct Link:<br />
<input type="text" id="codedirect" size=100 value="'.$imgurl.'" onclick="javascript:this.focus();this.select();" readonly="true" /><br />
HTML Code:<br />
<input type="text" id="codehtml" size=100 value=\'&lt;a href="'.$siteurl.'"&gt;&lt;img src="'.$imgurl.'" alt="'.$alt.'" /&gt;&lt/a&gt;\' onclick="javascript:this.focus();this.select();" readonly="true" /><br />
BBCode:<br />
<input type="text" id="codebb" size=100 value="[URL='.$siteurl.'][IMG]'.$imgurl.'[/IMG][/URL]" onclick="javascript:this.focus();this.select();" readonly="true" /><br />
</p>';

        } else 

            print '<p>Sorry, Max Picture size is 8Mb</p>';

    } else

        print '<p>Sorry, it is not allowed!</p>';

}

?>

</center>

<center>
<form enctype="multipart/form-data" action="<?php print preg_replace('/\/([^\/]+?)$/', '/', $_SERVER['PHP_SELF']) ?>" method="post">
<label for="file">Upload Picture: </label><input type="file" name="file" id="file" /> <br />
<small>(Max Pic. size is 8MB | Only .png, .jpg, .jpeg, .gif, .ico, .tif, .bmp, .webp file types are allowed)<br />
<?php
$directory = "./i/";
$filecount = 0;
$files = glob($directory . "*.{png,PNG,jpg,JPG,jpeg,JPEG,gif,GIF,ico,tif,bmp,BMP,webp}",GLOB_BRACE);
if ($files){
$filecount = count($files);
}
echo "Hosting $filecount images so far and counting...";
?></small><br />
<input name="submit" type="submit" value="Upload" class="button"> 
</form>
<!-- iLoveThis BEGIN CODE-->
<div class="share">
<a href="http://ilovethis.bl.ee" title="iLoveThis" target="_blank"><img src="http://ilovethis.bl.ee/images/heart.png"/></a><script src="http://ilovethis.bl.ee/js/ilovethis.js" type="text/javascript"></script>
</div>
<!-- iLoveThis END CODE-->
</center>

<hr />
	
<center>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7830715444538708";
/* eti ads1 */
google_ad_slot = "3142168608";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7830715444538708";
/* eti ads1 */
google_ad_slot = "3142168608";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-7830715444538708";
/* eti ads1 */
google_ad_slot = "3142168608";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</center>

<hr />	

<center>
<!-- Webcounter BEGIN CODE-->
<script language="Javascript" src="http://webcounter.bl.ee/counter.php?page=ebef9a8"></script><br />
<small><a href="http://webcounter.bl.ee" title="Free Web Counter" target="_blank">Own Free Web Counter Service Script - Open Source (with source code of the project)<br /></a></small>
<!-- Webcounter END CODE-->
<a href="http://eti.pw" target="_blank" title="KISS Project">Keep It Simple, Silly!</a><br />
<a href="dnl.php?f=eti simple image hosting script.zip" target="_blank">Download source code of this project</a>
<?php  
//lines counter in the file and show it - i use it about dnl counter:)
$file = "downloads.log";  
$lines = COUNT(FILE($file));  
echo "- dnl: $lines times";
?><br />
<a href="http://eti.pw" target="_blank">ETI</a> 1998-<?php
echo date("Y") ;
?>
</center>

</body>
</html>
