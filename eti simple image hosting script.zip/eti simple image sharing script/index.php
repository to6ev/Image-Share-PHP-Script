<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<LINK REL="SHORTCUT ICON" href="share-images.png">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="Description" content="Free Image Host - Share Pictures">
<meta name="Keywords" content="share picture, free image hosting, image host, image hosting, upload pictures, share pictures, pic share, share pic, share image, прикачи снимка, upload image, prikachi snimka, сподели картинка, сподели снимка" />
<meta name="Distribution" content="Free Image Host" />
<meta name="Author" content="www.ETI.pw" />
<meta name="Robots" content="index,follow" />
<title>Free Image Host</title>

<style type="text/css">
body {
  height: 100%;
  background: #13ec13;
}
a {
  color: #FF0000;
  text-decoration: none;
}
eti:hover {
  color: #FFFFFF;
  background-color: #000000;
}
eti { 
  background-color: yellow;
}
</style>

</head>
<body>
	
<?php
$siteurl = 'http://imgu.bl.ee'; // Site url Without Trailing slash
$textlogo = 'Share Pictures'; // Site Text Logo
$filedir = 'i'; // directory For Image Uploads  + Must Be Chmoded To 777 on Linux :)
$maxsize = 8388608; // Max File Size in bytes
$accepted = array('png', 'PNG', 'jpg', 'JPG', 'jpeg','JPEG', 'gif', 'GIF', 'ico', 'tif', 'bmp', 'webp');
$copyright = '<a href="http://et.pw">ETI 1998-2018</a>'
?>
	
<center>	
<h1><a href="./"><eti><?php print $textlogo; ?></eti></a></h1>

<?php

if($_SERVER['REQUEST_METHOD'] == 'POST') {

    preg_match('/\.([a-zA-Z]+?)$/', $_FILES['file']['name'], $matches);

    if(in_array(strtolower($matches[1]), $accepted)) {

        if($_FILES['file']['size'] <= $maxsize) {

            $newname = md5_file($_FILES['file']['tmp_name']).'.'.$matches[1];

            move_uploaded_file($_FILES['file']['tmp_name'], $filedir.'/'.$newname);

            $linkurl = 'http://'.$_SERVER['HTTP_HOST'].preg_replace('/\/([^\/]+?)$/', '/', $_SERVER['PHP_SELF']).'#'.$newname;

            $imgurl = 'http://'.$_SERVER['HTTP_HOST'].preg_replace('/\/([^\/]+?)$/', '/', $_SERVER['PHP_SELF']).$filedir.'/'.$newname;

            print '<h2>Picture Uploaded Successfuly!</h2> <p id="codes">
         
          <img src="'.$imgurl.'" height="300" alt="Uploaded Picture" >
<br />
<br />
Direct Link:<br />
<input type="text" id="codedirect" size=100 value="'.$imgurl.'" onclick="javascript:this.focus();this.select();" readonly="true" /><br />
HTML Code:<br />
<input type="text" id="codehtml" size=100 value=\'&lt;a href="'.$siteurl.'"&gt;&lt;img src="'.$imgurl.'" /&gt;&lt/a&gt;\' onclick="javascript:this.focus();this.select();" readonly="true" /><br />
BBCode:<br />
<input type="text" id="codebb" size=100 value="[URL='.$siteurl.'][IMG]'.$imgurl.'[/IMG][/URL]" onclick="javascript:this.focus();this.select();" readonly="true" /><br />';

        } else 

            print '<p>Sorry, Max Picture size is 8Mb</p>';

    } else

        print '<p>Sorry, it is not allowed!</p>';

}
?>

<form enctype="multipart/form-data" action="<?php print preg_replace('/\/([^\/]+?)$/', '/', $_SERVER['PHP_SELF']) ?>" method="post">
<label for="file">Upload Picture: </label><input type="file" name="file" id="file" /> <br />
<small>(Max Pic. size is 8MB | Only .png, .jpg, .jpeg, .gif, .ico, .tif, .bmp, .webp file types are allowed)<br />
<?php
$directory = "./i/";
$filecount = 0;
$files = glob($directory . "*.{png,PNG,jpg,JPG,jpeg,JPEG,gif,GIF,ico,tif,bmp,BMP,webp}",GLOB_BRACE);
if ($files){
$filecount = count($files);
}
echo "Hosting $filecount images so far and counting...";
?></small><br />
<input name="submit" type="submit" value="Upload" class="button"> 
</form>

<hr />	

<!-- iLoveThis BEGIN CODE-->
<div class="share">
<a href="http://ilovethis.bl.ee" title="iLoveThis" target="_blank"><img src="http://ilovethis.bl.ee/images/heart.png"/></a><script src="http://ilovethis.bl.ee/js/ilovethis.js" type="text/javascript"></script>
</div>
<!-- iLoveThis END CODE-->

<!-- BEGIN VIRTUAL CANDLE CODE-->
<a href="http://lightingacandle.pe.hu" alt="Light Virtual Candle" title="Light a Candle" target="_blank"><img src="http://lightingacandle.pe.hu/icons/virtualcandlebutton.jpg"/></a>
<!-- END VIRTUAL CANDLE CODE-->
<br />

<!-- Webcounter BEGIN CODE-->
<script language="Javascript" src="http://webcounter.bl.ee/counter.php?page=ebef9a8"></script><br />
<small><a href="http://webcounter.bl.ee" title="Free Web Counter" target="_blank">Own Free Web Counter Service Script - Open Source (with source code of the project)<br /></a></small>
<!-- Webcounter END CODE-->

<a href="http://eti.pw" target="_blank" title="KISS Project">Keep It Simple, Silly!</a>

<br />

<a href="http://eti.pw" target="_blank">ETI</a> 1998-<?php
echo date("Y") ;
// print $copyright;
?>
</center>

</body>
</html>
