<?php
$siteurl = 'http://imgu.bl.ee'; // Site url Without Trailing slash
$textlogo = 'Share Pictures'; // Site Logo
$filedir = 'i'; // directory For Image Uploads  + Must Be Chmoded To 777 on Linux :)
$maxsize = 8388608; // Max File Size in bytes
$accepted = array('png', 'PNG', 'jpg', 'JPG', 'jpeg','JPEG', 'gif', 'GIF', 'ico', 'tif', 'bmp', 'webp');
$copyright = '<a href="http://et.pw">ETI 1998-2018</a>'
?>
